package learnify.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import learnify.database.DataManager;
import learnify.models.*;
import java.util.List;
import java.util.ArrayList;

public class AdminDashboard extends JFrame {
    private Admin admin;
    private DataManager dataManager;
    private JTable dataTable;
    private DefaultTableModel tableModel;

    public AdminDashboard(Admin admin) {
        this.admin = admin;
        this.dataManager = DataManager.getInstance();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Learnify - Admin Dashboard");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(139, 0, 139));
        headerPanel.setPreferredSize(new Dimension(1000, 60));
        JLabel welcomeLabel = new JLabel("Admin Console - " + admin.getUsername());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.WHITE);
        headerPanel.add(welcomeLabel);

        // Navigation Panel
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(230, 200, 230));
        navPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JButton manageUsersBtn = new JButton("Manage Users");
        JButton manageCoursesBtn = new JButton("Manage Courses");
        JButton viewAllDataBtn = new JButton("System Statistics");
        JButton addCourseBtn = new JButton("Add Course");
        JButton deleteBtn = new JButton("Delete");
        JButton logoutBtn = new JButton("Logout");

        manageUsersBtn.addActionListener(e -> displayAllUsers());
        manageCoursesBtn.addActionListener(e -> displayAllCourses());
        viewAllDataBtn.addActionListener(e -> displaySystemStats());
        addCourseBtn.addActionListener(e -> openAddCourseDialog());
        deleteBtn.addActionListener(e -> handleDelete());
        logoutBtn.addActionListener(e -> handleLogout());

        navPanel.add(manageUsersBtn);
        navPanel.add(manageCoursesBtn);
        navPanel.add(viewAllDataBtn);
        navPanel.add(addCourseBtn);
        navPanel.add(deleteBtn);
        navPanel.add(logoutBtn);

        // Table
        JPanel contentPanel = new JPanel(new BorderLayout());
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Details"}, 0);
        dataTable = new JTable(tableModel);
        dataTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(dataTable);
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(navPanel, BorderLayout.PAGE_START);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);
        displayAllUsers();
    }

    // ---------------------- Load Users ----------------------
    private void displayAllUsers() {
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String[]{"User ID", "Username", "Role", "Email"});

        List<User> allUsers = dataManager.getAllUsers();
        for (User user : allUsers) {
            tableModel.addRow(new Object[]{
                    user.getUserId(),
                    user.getUsername(),
                    user.getRole(),
                    user.getEmail()
            });
        }
    }

    // ---------------------- Load Courses ----------------------
    private void displayAllCourses() {
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String[]{"Course ID", "Course Name", "Teacher", "Students"});

        List<Course> allCourses = dataManager.getAllCourses();
        for (Course course : allCourses) {
            tableModel.addRow(new Object[]{
                    course.getCourseId(),
                    course.getCourseName(),
                    course.getTeacherId(),
                    course.getEnrollmentCount()
            });
        }
    }

    // ---------------------- System Stats ----------------------
    private void displaySystemStats() {
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String[]{"Metric", "Count"});

        tableModel.addRow(new Object[]{"Total Users", dataManager.getAllUsers().size()});
        tableModel.addRow(new Object[]{"Total Courses", dataManager.getAllCourses().size()});
        tableModel.addRow(new Object[]{"Total Quizzes", dataManager.getAllCourses().size()});
    }

    // ---------------------- Add New Course Dialog ----------------------
    private void openAddCourseDialog() {
        JDialog dialog = new JDialog(this, "Add New Course", true);
        dialog.setSize(450, 400);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JTextField courseIdField = new JTextField(20);
        JTextField courseNameField = new JTextField(20);
        JTextField descriptionField = new JTextField(20);
        JComboBox<String> teacherCombo = new JComboBox<>();

        // ✅ FIXED: Create list to track teachers properly
        List<Teacher> availableTeachers = new ArrayList<>();
        for (User u : dataManager.getAllUsers()) {
            if (u instanceof Teacher) {
                Teacher t = (Teacher) u;
                availableTeachers.add(t);
                teacherCombo.addItem(t.getUsername() + " (" + t.getUserId() + ")");
            }
        }

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Course ID:"), gbc);
        gbc.gridx = 1;
        panel.add(courseIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Course Name:"), gbc);
        gbc.gridx = 1;
        panel.add(courseNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1;
        panel.add(descriptionField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Assign Teacher:"), gbc);
        gbc.gridx = 1;
        panel.add(teacherCombo, gbc);

        JButton submitButton = new JButton("Create Course");
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;

        submitButton.addActionListener(e -> {
            try {
                // ✅ FIXED: Get teacher by index instead of casting
                int selectedIndex = teacherCombo.getSelectedIndex();
                if (selectedIndex == -1 || availableTeachers.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Please select a teacher!");
                    return;
                }

                Teacher selectedTeacher = availableTeachers.get(selectedIndex);
                
                Course course = new Course(
                    courseIdField.getText(), 
                    courseNameField.getText(),
                    descriptionField.getText(), 
                    selectedTeacher.getUserId(),
                    "2025-11-26", 
                    "2025-12-26", 
                    3.0
                );

                dataManager.addCourse(course);

                // ✅ FIXED: Only assign to the selected teacher
                selectedTeacher.assignCourse(course.getCourseId());
                dataManager.updateUser(selectedTeacher);

                JOptionPane.showMessageDialog(dialog, "Course created successfully!");
                dialog.dispose();
                displayAllCourses();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        panel.add(submitButton, gbc);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    // ---------------------- DELETE FUNCTION ----------------------
    private void handleDelete() {
        int selectedRow = dataTable.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
            return;
        }

        String id = tableModel.getValueAt(selectedRow, 0).toString();
        String firstColumnName = tableModel.getColumnName(0);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete: " + id + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            if (firstColumnName.equals("User ID")) {
                dataManager.deleteUser(id);
                JOptionPane.showMessageDialog(this, "User deleted successfully!");
                displayAllUsers();

            } else if (firstColumnName.equals("Course ID")) {
                dataManager.deleteCourse(id);
                JOptionPane.showMessageDialog(this, "Course deleted successfully!");
                displayAllCourses();

            } else {
                JOptionPane.showMessageDialog(this, "Delete not supported on this screen.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting item: " + ex.getMessage());
        }
    }

    // ---------------------- Logout ----------------------
    private void handleLogout() {
        this.dispose();
        new LoginFrame().setVisible(true);
    }
}