package learnify.models;

import java.io.Serializable;
import java.util.*;

public class Quiz implements Serializable {
    private static final long serialVersionUID = 1L;
    private String quizId;
    private String quizTitle;
    private String courseId;
    private String teacherId;
    private List<String> questions;
    private Map<String, String> answers;
    private int totalMarks;
    private String dueDate;
    private boolean published;

    public Quiz(String quizId, String quizTitle, String courseId, 
                String teacherId, int totalMarks, String dueDate) {
        this.quizId = quizId;
        this.quizTitle = quizTitle;
        this.courseId = courseId;
        this.teacherId = teacherId;
        this.questions = new ArrayList<>();
        this.answers = new HashMap<>();
        this.totalMarks = totalMarks;
        this.dueDate = dueDate;
        this.published = false;
    }

    public void addQuestion(String question) { questions.add(question); }
    public void setAnswer(String questionId, String answer) { answers.put(questionId, answer); }
    public void publishQuiz() { this.published = true; }

    public String getQuizId() { return quizId; }
    public String getQuizTitle() { return quizTitle; }
    public String getCourseId() { return courseId; }
    public List<String> getQuestions() { return questions; }
    public Map<String, String> getAnswers() { return answers; }
    public int getTotalMarks() { return totalMarks; }
    public String getDueDate() { return dueDate; }
    public boolean isPublished() { return published; }
}
